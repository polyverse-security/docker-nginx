
void main(){
  printf("DUpa");
  }
